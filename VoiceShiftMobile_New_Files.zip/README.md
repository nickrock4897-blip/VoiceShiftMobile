# VoiceShift Mobile

A clean Android Studio / GitHub Actions starter project for a voice-changer app concept.

## Build with GitHub Actions

1. Upload the *contents* of this folder to the root of your GitHub repository.
2. Make sure `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/` are directly in the repository root.
3. Commit to the `main` branch.
4. Open **Actions** and wait for **Android Build** to finish.
5. Download the `VoiceShiftMobile-debug` artifact from the successful workflow run.

## Current scope

This is a UI/build prototype only. The Start button toggles demo status. It does not yet perform AI voice conversion, record/process microphone audio, or route altered audio into Roblox. Those features need a real audio pipeline and a compatible model, and Android apps generally cannot act as a system-wide virtual microphone for another app without platform/device support.
