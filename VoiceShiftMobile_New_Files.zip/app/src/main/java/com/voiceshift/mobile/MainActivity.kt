package com.voiceshift.mobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private var isRunning = false
    private lateinit var statusText: TextView
    private lateinit var startButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 18, 32)
        window.navigationBarColor = Color.rgb(15, 18, 32)
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.rgb(15, 18, 32))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)

        val logo = TextView(this).apply {
            text = "🎙️"
            textSize = 54f
            gravity = Gravity.CENTER
        }
        content.addView(logo, matchWrap())

        val title = TextView(this).apply {
            text = "VoiceShift Mobile"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        content.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Dein Voice-Changer-Projekt"
            textSize = 16f
            setTextColor(Color.rgb(174, 183, 205))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(28))
        }
        content.addView(subtitle, matchWrap())

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(29, 34, 54))
        }

        val sectionTitle = TextView(this).apply {
            text = "Status"
            textSize = 18f
            setTextColor(Color.WHITE)
        }
        card.addView(sectionTitle, matchWrap())

        statusText = TextView(this).apply {
            text = "Bereit – Voice-Engine ist noch nicht eingebaut."
            textSize = 15f
            setTextColor(Color.rgb(220, 225, 240))
            setPadding(0, dp(10), 0, dp(16))
        }
        card.addView(statusText, matchWrap())

        startButton = Button(this).apply {
            text = "Projekt starten"
            isAllCaps = false
            setOnClickListener { toggleState() }
        }
        card.addView(startButton, matchWrap())

        val note = TextView(this).apply {
            text = "Wichtig: Diese Version ist ein funktionierender UI-/Build-Prototyp. Sie verändert deine Stimme noch nicht und leitet Audio nicht in Roblox weiter."
            textSize = 14f
            setTextColor(Color.rgb(255, 207, 128))
            setPadding(0, dp(18), 0, 0)
        }
        card.addView(note, matchWrap())

        content.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val nextTitle = TextView(this).apply {
            text = "Nächste Entwicklungsstufen"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, dp(26), 0, dp(10))
        }
        content.addView(nextTitle, matchWrap())

        val nextSteps = TextView(this).apply {
            text = "1. Mikrofonaufnahme hinzufügen\\n2. Audio-Verarbeitung testen\\n3. Voice-Conversion-Modell integrieren\\n4. Prüfen, welche Android-/Roblox-Audio-Routen überhaupt unterstützt werden"
                .replace("\\\\n", "\\n")
            textSize = 15f
            setTextColor(Color.rgb(210, 216, 232))
            setLineSpacing(dp(5).toFloat(), 1f)
        }
        content.addView(nextSteps, matchWrap())

        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun toggleState() {
        isRunning = !isRunning
        if (isRunning) {
            statusText.text = "Demo läuft. Noch keine echte Stimmveränderung aktiv."
            startButton.text = "Demo stoppen"
        } else {
            statusText.text = "Bereit – Voice-Engine ist noch nicht eingebaut."
            startButton.text = "Projekt starten"
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
