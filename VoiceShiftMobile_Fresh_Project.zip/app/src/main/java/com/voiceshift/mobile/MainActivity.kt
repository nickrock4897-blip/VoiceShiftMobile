package com.voiceshift.mobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var active = false
    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(15, 18, 32))
        }

        val title = TextView(this).apply {
            text = "VoiceShift"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Mobile voice effects prototype"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Status: inactive"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 24)
        }
        toggle = Button(this).apply {
            text = "Start prototype"
            setOnClickListener {
                active = !active
                status.text = if (active) {
                    "Prototype enabled\nNo live voice conversion is running yet."
                } else {
                    "Status: inactive"
                }
                toggle.text = if (active) "Stop prototype" else "Start prototype"
            }
        }
        val note = TextView(this).apply {
            text = "This starter app does not yet convert your voice or route audio into Roblox. A real-time voice model and Android audio-routing support still need to be added."
            textSize = 14f
            setTextColor(Color.rgb(200, 205, 220))
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }

        page.addView(title, matchWrap())
        page.addView(subtitle, matchWrap())
        page.addView(status, matchWrap())
        page.addView(toggle, matchWrap())
        page.addView(note, matchWrap())
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
