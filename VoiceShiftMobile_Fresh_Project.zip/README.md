# VoiceShiftMobile — fresh starter project

This is a minimal Android/Kotlin project intended to confirm that GitHub Actions can build and upload an APK.

## Upload to GitHub

1. Extract this ZIP on your phone.
2. Open your VoiceShiftMobile GitHub repository.
3. Remove the old files if you want a clean start.
4. Upload the contents of this folder so that `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/` are directly in the repository root.
5. Commit to the `main` branch.
6. Open Actions and run Build VoiceShiftMobile.
7. If it succeeds, open the run and download `VoiceShiftMobile-debug-APK` under Artifacts.

## Important limitation

This is a starter prototype UI, not a finished real-time AI voice changer. It does not include a trained RVC model, real-time voice conversion, or virtual microphone routing into Roblox.
