# APK nur mit dem Handy bauen (GitHub Actions)

Dieser Weg vermeidet, dass du den ganzen Projektordner auf dem Handy einzeln hochladen musst.

## Schritt 1 — Source-ZIP ins Repository legen
1. Öffne GitHub im Browser und erstelle ein neues Repository. Private oder öffentliche Sichtbarkeit ist deine Entscheidung.
2. Öffne das Repository und wähle **Add file → Upload files**.
3. Lade `VoiceShiftMobile_Source.zip` unverändert hoch und committe die Datei.

## Schritt 2 — den Workflow anlegen
1. Wähle im Repository **Add file → Create new file**.
2. Gib als Dateinamen genau `.github/workflows/build.yml` ein.
3. Öffne die separat mitgelieferte Datei `GITHUB_BOOTSTRAP_WORKFLOW.yml`, kopiere deren kompletten Inhalt in den GitHub-Editor und committe ihn.

## Schritt 3 — APK herunterladen
1. Öffne den Tab **Actions**.
2. Öffne den Lauf **Build VoiceShift Mobile APK**. Warte auf den grünen Haken.
3. Lade unter **Artifacts** `VoiceShiftMobile-debug-apk` herunter.
4. Entpacke das Artefakt-ZIP. Darin liegt `app-debug.apk`.
5. Installiere die APK auf deinem eigenen Android-Handy. Android kann vorher nach Bestätigung für die Installation aus dieser Quelle fragen.

## Was ein grüner Haken aussagt
Er bestätigt nur, dass der Quellcode in der GitHub-Umgebung kompiliert und die enthaltenen Unit-Tests bestanden hat. Er bestätigt **nicht**, dass ein beliebiges KI-Modell kompatibel ist oder Roblox die bearbeitete Stimme aufnimmt. Das muss danach auf einem echten Gerät getestet werden.
