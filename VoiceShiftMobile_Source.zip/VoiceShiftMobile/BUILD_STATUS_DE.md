# VoiceShift Mobile — Entwicklungsstatus

## Implementiert im Quellcode
- Android-Oberfläche mit Start/Stop.
- Foreground-Service für lokale Live-Audioverarbeitung.
- AudioRecord/AudioTrack-Pipeline mit 48 kHz Mono.
- DSP-Presets Robot, Radio, Alien und Clean.
- Schalter zum Mithören der bearbeiteten Stimme, standardmäßig aus.
- Import einer ONNX-Datei ins private App-Verzeichnis.
- Experimenteller ONNX-Adapter für einfache Audio-zu-Audio-Graphen mit einem FLOAT-Eingang und einem Ausgang.
- GitHub Actions zum Bauen und Bereitstellen einer Debug-APK.

## Noch nicht fertig / nicht bewiesen
- RVC-Modelpacks (Synth + HuBERT/ContentVec + RMVPE) werden nicht als echter RVC-Pipeline unterstützt.
- Die App stellt kein virtuelles Android-Mikrofon bereit. Die direkte Einspeisung der veränderten Stimme in Roblox ist auf normalem Android nicht gewährleistet.
- Kein echter Geräte-Test auf Xiaomi 13C oder einem anderen Android-Handy durchgeführt.
- Der Android-Build konnte in dieser Umgebung nicht ausgeführt werden, weil hier kein Android-SDK/Gradle installiert ist und keine Paketdownloads möglich waren.

## Abnahmekriterien für „funktioniert vollständig“
1. GitHub Actions Debug-APK-Build grün.
2. APK installiert und Mikrofonfreigabe auf echtem Android-Gerät getestet.
3. Jeder DSP-Effekt ohne Knacken/Absturz in Echtzeit getestet.
4. Kompatibles ONNX-Audio-Modell geladen und dessen Audioausgabe verifiziert.
5. Roblox-Mikrofontest beweist, dass die andere Person tatsächlich die bearbeitete Stimme hört. Ohne diesen Nachweis darf die App nicht als vollständig Roblox-kompatibel bezeichnet werden.

## Prüfungen in dieser Entwicklungsrunde
- Die reine DSP-Datei `VoiceEffects.kt` wurde lokal mit dem Kotlin-Compiler kompiliert.
- Ein Smoke-Test hat alle vier Presets (`CLEAN`, `ROBOT`, `RADIO`, `ALIEN`) mit 1024 Audio-Samples ausgeführt; Ausgabe war endlich und im Bereich -1 bis +1.
- Android-XML-Dateien ließen sich parsen; beide GitHub-Workflow-YAML-Dateien ließen sich parsen.
- Die vollständige Android-App sowie ONNX-Modelllauf und Roblox-Voice-Chat konnten hier nicht gebaut bzw. auf einem Gerät getestet werden.
