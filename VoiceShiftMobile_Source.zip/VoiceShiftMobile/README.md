# VoiceShift Mobile (Android) — Alpha 0.1.0

An Android prototype for local live audio effects, a listen-to-self toggle, importing a narrow class of ONNX audio models, and building a debug APK with GitHub Actions.

## Included now

- Native Android app (Kotlin; no desktop IDE required after upload to GitHub).
- Foreground microphone service using `AudioRecord` and `AudioTrack` at 48 kHz mono.
- Live DSP effects: Robot, Radio, Alien, Clean.
- Toggle for local monitoring of processed audio (off by default).
- ONNX model file import stored in app-private storage.
- Experimental ONNX runtime adapter for a single FLOAT input tensor `[1, samples]` and one audio output.
- GitHub Actions workflow compiling `app-debug.apk` and uploading it as an artifact.

## Important limitations (not hidden)

1. **Not a completed Roblox voice-chat solution.** Ordinary Android apps cannot register a virtual microphone for Roblox. Local audio playback is not the same as routing processed audio into Roblox's microphone capture. The Roblox path has not been proven and requires real-device tests; stock Android's audio focus and microphone arbitration also vary by device.
2. **Generic ONNX model support is narrow and experimental.** A model must accept one FLOAT tensor shaped `[1, samples]` and output audio in the same sample-rate domain. The adapter is not a general RVC runner.
3. **Typical RVC packs are not supported yet.** Desktop RVC exports commonly rely on multiple graphs/features (for example synthesizer, content encoder, and pitch extractor) and model-specific preprocessing. Importing a `.pth`, `.index`, or arbitrary `.onnx` file does not make it compatible. This app currently imports `.onnx` only and checks compatibility on start.
4. **Build verification:** the source has not been compiled in this environment because Android SDK/Gradle are not installed here and outbound package downloads are unavailable. The GitHub Actions workflow is included to run an actual build when this project is pushed to GitHub. A successful cloud build still needs a real-device smoke test.

## Build APK from a phone with GitHub

1. Download and extract this ZIP.
2. Open GitHub in your browser and create a new repository.
3. Upload the contents of this folder (upload the files, not the outer folder itself).
4. Open the repository's **Actions** tab. The workflow named **Build Android APK** should start automatically.
5. Once it has a green check, open that run and download **VoiceShiftMobile-debug-apk** under Artifacts.
6. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

## Controls

- **START** opens the foreground microphone service after microphone permission is granted.
- **STOP** releases the microphone and speaker output.
- **Eigene bearbeitete Stimme mithören** toggles local audio monitoring only.
- Effect menu changes the local DSP effect.
- **ONNX-MODELL HINZUFÜGEN** imports a model for the experimental audio-to-audio adapter.

For feedback, use headphones and start monitoring at low volume to avoid acoustic feedback. Avoid using voice models of other people without their permission.
