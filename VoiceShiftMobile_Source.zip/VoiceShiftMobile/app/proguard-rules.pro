# R8 is disabled for the alpha build. Keep ONNX Runtime classes if minification is enabled later.
-keep class ai.onnxruntime.** { *; }
