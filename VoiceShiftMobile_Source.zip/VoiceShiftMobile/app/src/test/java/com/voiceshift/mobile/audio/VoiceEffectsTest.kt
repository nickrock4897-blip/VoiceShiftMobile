package com.voiceshift.mobile.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class VoiceEffectsTest {
    @Test fun everyPresetKeepsFrameLengthAndFiniteSamples() {
        val source = FloatArray(1024) { i -> (0.4 * sin(i * 2.0 * Math.PI * 220.0 / 48000.0)).toFloat() }
        for (preset in listOf("CLEAN", "ROBOT", "RADIO", "ALIEN")) {
            val result = VoiceEffects().process(source, preset)
            assertEquals(source.size, result.size)
            assertTrue("$preset had a NaN or infinite value", result.all { it.isFinite() })
            assertTrue("$preset exceeded PCM range", result.all { it in -1f..1f })
        }
    }

    @Test fun cleanPresetRetainsSignalShapeWithinLimiterRange() {
        val source = floatArrayOf(-1f, -0.5f, 0f, 0.5f, 1f)
        val output = VoiceEffects().process(source, "CLEAN")
        assertEquals(source.size, output.size)
        assertTrue(output.first() < 0f)
        assertTrue(output.last() > 0f)
        assertTrue(output.all { it in -1f..1f })
    }
}
