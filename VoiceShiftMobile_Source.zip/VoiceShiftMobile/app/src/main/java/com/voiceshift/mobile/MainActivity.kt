package com.voiceshift.mobile

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    companion object {
        private const val MIC_PERMISSION = 7001
        private const val PICK_MODEL = 7002
    }

    private val bg = Color.rgb(15, 15, 24)
    private val surface = Color.rgb(28, 27, 42)
    private val accent = Color.rgb(177, 126, 255)
    private val text = Color.rgb(246, 244, 255)
    private val muted = Color.rgb(172, 169, 192)
    private lateinit var statusText: TextView
    private lateinit var modelText: TextView
    private lateinit var modelSpinner: Spinner
    private var refreshingModels = false
    private lateinit var monitorSwitch: Switch
    private lateinit var effectSpinner: Spinner
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private val prefs by lazy { getSharedPreferences(VoiceChangerService.PREFS, Context.MODE_PRIVATE) }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            statusText.text = intent?.getStringExtra(VoiceChangerService.KEY_STATUS) ?: "Bereit"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        statusText.text = prefs.getString(VoiceChangerService.KEY_STATUS, "Bereit · noch nicht gestartet")
        refreshModels()
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, IntentFilter("com.voiceshift.mobile.STATUS"), Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION") registerReceiver(statusReceiver, IntentFilter("com.voiceshift.mobile.STATUS"))
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "VOICE\u2009SHIFT"
            textSize = 13f; letterSpacing = .2f; setTextColor(accent); typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(brand)
        root.addView(label("Mobile Voice Lab", 30f, true).also { it.setPadding(0, dp(4), 0, dp(2)) })
        root.addView(label("Echtzeit-Audio · Effekte · eigene ONNX-Modelle", 14f, false, muted))

        val statusCard = card()
        statusCard.addView(label("STATUS", 12f, true, muted))
        statusText = label("Bereit · noch nicht gestartet", 15f, true, text)
        statusText.setPadding(0, dp(8), 0, 0)
        statusCard.addView(statusText)
        root.addView(statusCard, marginTop(20))

        val controlCard = card()
        controlCard.addView(label("LIVE AUDIO", 12f, true, muted))
        controlCard.addView(label("Mikrofonverarbeitung auf dem Handy", 17f, true, text).also { it.setPadding(0, dp(6), 0, dp(10)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        startButton = button("START", accent, Color.rgb(20, 15, 31)) { startAudio() }
        stopButton = button("STOP", Color.rgb(61, 57, 77), text) { sendService(VoiceChangerService.ACTION_STOP) }
        row.addView(startButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(8) })
        row.addView(stopButton, LinearLayout.LayoutParams(0, dp(50), 1f))
        controlCard.addView(row)
        monitorSwitch = Switch(this).apply {
            text = "Eigene bearbeitete Stimme mithören"
            setTextColor(text); textSize = 14f
            isChecked = prefs.getBoolean(VoiceChangerService.KEY_MONITOR, false)
            setOnCheckedChangeListener { _, enabled ->
                prefs.edit().putBoolean(VoiceChangerService.KEY_MONITOR, enabled).apply()
                sendService(VoiceChangerService.ACTION_MONITOR) { putExtra(VoiceChangerService.EXTRA_ENABLED, enabled) }
                statusText.text = if (enabled) "Mithören eingeschaltet · lokale Ausgabe" else "Mithören ausgeschaltet"
            }
        }
        controlCard.addView(monitorSwitch, marginTop(10))
        root.addView(controlCard, marginTop(12))

        val effectsCard = card()
        effectsCard.addView(label("STIMM-EFFEKT", 12f, true, muted))
        effectSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Robot", "Radio", "Alien", "Clean / Original"))
            val stored = prefs.getString(VoiceChangerService.KEY_EFFECT, "ROBOT") ?: "ROBOT"
            setSelection(listOf("ROBOT", "RADIO", "ALIEN", "CLEAN").indexOf(stored).coerceAtLeast(0))
            setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val key = listOf("ROBOT", "RADIO", "ALIEN", "CLEAN")[position]
                    prefs.edit().putString(VoiceChangerService.KEY_EFFECT, key).apply()
                    sendService(VoiceChangerService.ACTION_EFFECT) { putExtra(VoiceChangerService.EXTRA_EFFECT, key) }
                }
            })
        }
        effectsCard.addView(effectSpinner, marginTop(8))
        effectsCard.addView(label("Diese Effekte laufen lokal in Echtzeit. Sie sind DSP-Effekte, keine KI-Stimmkopie.", 12f, false, muted).also { it.setPadding(0, dp(8), 0, 0) })
        root.addView(effectsCard, marginTop(12))

        val modelsCard = card()
        modelsCard.addView(label("DEINE MODELLE", 12f, true, muted))
        modelSpinner = Spinner(this)
        modelsCard.addView(modelSpinner, marginTop(6))
        modelText = label("Noch kein Modell gewählt", 14f, true, text).also { it.setPadding(0, dp(8), 0, dp(12)) }
        modelsCard.addView(modelText)
        modelsCard.addView(button("ONNX-MODELL HINZUFÜGEN", Color.rgb(49, 42, 68), text) { pickModel() }, LinearLayout.LayoutParams(-1, dp(48)))
        modelsCard.addView(label("Hinweis: Diese Alpha-Version akzeptiert nur Modelle mit genau einem FLOAT-Audio-Eingang [1, Samples] und einem Audio-Ausgang. Übliche RVC-Pakete mit HuBERT/RMVPE/Synth werden noch nicht unterstützt.", 12f, false, muted).also { it.setPadding(0, dp(10), 0, 0) })
        root.addView(modelsCard, marginTop(12))

        val warningCard = card()
        warningCard.addView(label("ROBLOX-HINWEIS", 12f, true, Color.rgb(255, 198, 125)))
        warningCard.addView(label("Android bietet normalen Apps kein virtuelles Mikrofon, das Roblox direkt auswählen kann. VoiceShift kann die Stimme lokal verändern und optional über Kopfhörer/Lautsprecher ausgeben; das beweist nicht, dass Roblox diese bearbeitete Stimme aufnimmt. Nutze zum Mithören am besten Kopfhörer, um Rückkopplung zu vermeiden.", 13f, false, text).also { it.setPadding(0, dp(8), 0, 0) })
        root.addView(warningCard, marginTop(12))
        root.addView(label("VOICE SHIFT MOBILE · ALPHA 0.1.0 · NO CLOUD AUDIO", 10f, true, muted).also { it.gravity = Gravity.CENTER; it.setPadding(0, dp(20), 0, 0) })

        setContentView(scroll)
    }

    private fun startAudio() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), MIC_PERMISSION)
            return
        }
        sendService(VoiceChangerService.ACTION_START)
        statusText.text = "Starte Mikrofon …"
    }

    private fun pickModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/onnx", "application/octet-stream"))
        }
        startActivityForResult(intent, PICK_MODEL)
    }

    @Deprecated("Using legacy result callback for broad Android device support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_MODEL || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val name = queryDisplayName(uri) ?: "custom_model.onnx"
            if (!name.lowercase().endsWith(".onnx")) throw IllegalArgumentException("Bitte eine .onnx-Datei auswählen.")
            val modelDir = File(filesDir, "models").apply { mkdirs() }
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val target = File(modelDir, "${System.currentTimeMillis()}_$safeName")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(target).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Datei konnte nicht gelesen werden.")
            prefs.edit().putString(VoiceChangerService.KEY_MODEL, target.absolutePath).apply()
            refreshModels()
            sendService(VoiceChangerService.ACTION_MODEL) { putExtra(VoiceChangerService.EXTRA_MODEL, target.absolutePath) }
            Toast.makeText(this, "Modell importiert. Kompatibilität wird beim Start geprüft.", Toast.LENGTH_LONG).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Modell konnte nicht importiert werden: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshModels() {
        val modelDir = File(filesDir, "models")
        val models = modelDir.listFiles()?.filter { it.isFile && it.extension.equals("onnx", true) }?.sortedBy { it.name } ?: emptyList()
        val selectedPath = prefs.getString(VoiceChangerService.KEY_MODEL, null)
        refreshingModels = true
        val entries = if (models.isEmpty()) listOf("Noch kein Modell importiert") else models.map { it.name }
        modelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, entries)
        val selectedIndex = models.indexOfFirst { it.absolutePath == selectedPath }.coerceAtLeast(0)
        modelSpinner.setSelection(selectedIndex)
        modelSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (refreshingModels || models.isEmpty() || position !in models.indices) return
                val chosen = models[position]
                prefs.edit().putString(VoiceChangerService.KEY_MODEL, chosen.absolutePath).apply()
                modelText.text = "${chosen.name}\n${chosen.length() / (1024 * 1024)} MB · wird beim Start geprüft"
                sendService(VoiceChangerService.ACTION_MODEL) { putExtra(VoiceChangerService.EXTRA_MODEL, chosen.absolutePath) }
            }
        }
        val chosen = models.getOrNull(selectedIndex)
        modelText.text = if (chosen != null) "${chosen.name}\n${chosen.length() / (1024 * 1024)} MB · wird beim Start geprüft" else "Noch kein Modell importiert"
        refreshingModels = false
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private inline fun sendService(action: String, extras: Intent.() -> Unit = {}) {
        val intent = Intent(this, VoiceChangerService::class.java).setAction(action).apply(extras)
        if (Build.VERSION.SDK_INT >= 26 && action == VoiceChangerService.ACTION_START) startForegroundService(intent) else startService(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIC_PERMISSION && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startAudio()
        else if (requestCode == MIC_PERMISSION) Toast.makeText(this, "Mikrofonzugriff wird benötigt.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        try { unregisterReceiver(statusReceiver) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(20).toFloat() }
    }

    private fun label(value: String, size: Float, bold: Boolean, color: Int = text): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun button(value: String, color: Int, textColor: Int, action: () -> Unit): Button = Button(this).apply {
        text = value; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(textColor); isAllCaps = false
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
        setOnClickListener { action() }
    }

    private fun marginTop(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
