package com.voiceshift.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.voiceshift.mobile.audio.RealtimeAudioEngine

class VoiceChangerService : Service() {
    companion object {
        const val ACTION_START = "com.voiceshift.mobile.START"
        const val ACTION_STOP = "com.voiceshift.mobile.STOP"
        const val ACTION_MONITOR = "com.voiceshift.mobile.MONITOR"
        const val ACTION_EFFECT = "com.voiceshift.mobile.EFFECT"
        const val ACTION_MODEL = "com.voiceshift.mobile.MODEL"
        const val EXTRA_ENABLED = "enabled"
        const val EXTRA_EFFECT = "effect"
        const val EXTRA_MODEL = "model"
        const val PREFS = "voiceshift_settings"
        const val KEY_MONITOR = "monitor"
        const val KEY_EFFECT = "effect"
        const val KEY_MODEL = "model_path"
        const val KEY_STATUS = "status"
        private const val CHANNEL_ID = "voiceshift_recording"
        private const val NOTIFICATION_ID = 2308
    }

    private var engine: RealtimeAudioEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Settings can be changed before audio starts; persist them in Activity and avoid leaving
        // an idle started service alive just because a control changed.
        if (engine == null && intent?.action != ACTION_START && intent?.action != ACTION_STOP) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_START -> startAudio()
            ACTION_STOP -> {
                engine?.stop(); engine = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_MONITOR -> engine?.setMonitoring(intent.getBooleanExtra(EXTRA_ENABLED, false))
            ACTION_EFFECT -> engine?.setEffect(intent.getStringExtra(EXTRA_EFFECT) ?: "CLEAN")
            ACTION_MODEL -> engine?.setModel(intent.getStringExtra(EXTRA_MODEL))
        }
        return START_NOT_STICKY
    }

    private fun startAudio() {
        if (engine?.isRunning() == true) return
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        engine = RealtimeAudioEngine(
            onStatus = { updateStatus(it) },
            monitoring = prefs.getBoolean(KEY_MONITOR, false),
            effect = prefs.getString(KEY_EFFECT, "ROBOT") ?: "ROBOT",
            modelPath = prefs.getString(KEY_MODEL, null)
        ).also { it.start() }
    }

    private fun updateStatus(status: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_STATUS, status).apply()
        sendBroadcast(Intent("com.voiceshift.mobile.STATUS").setPackage(packageName).putExtra(KEY_STATUS, status))
    }

    private fun buildNotification(): Notification {
        val launch = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("VoiceShift läuft")
            .setContentText("Lokale Audiobearbeitung aktiv")
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "VoiceShift Audio", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        engine?.stop(); engine = null
        super.onDestroy()
    }
}
