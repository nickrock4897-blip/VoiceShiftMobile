package com.voiceshift.mobile.model

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.Closeable
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Experimental adapter for a narrow model contract: one FLOAT input tensor shaped [1, samples]
 * and one FLOAT output tensor carrying processed mono audio. Ordinary RVC model packs do not
 * follow this single-tensor contract and are not supported by this adapter yet.
 */
class OnnxAudioModel(modelPath: String) : Closeable {
    private val environment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String
    private val inputFrameCount: Int?

    init {
        val options = OrtSession.SessionOptions()
        val opened = try {
            environment.createSession(modelPath, options)
        } finally {
            options.close()
        }
        try {
            require(opened.inputNames.size == 1) {
                "Dieses Modell hat ${opened.inputNames.size} Eingänge. Unterstützt wird derzeit genau ein Audio-Eingang."
            }
            require(opened.outputNames.isNotEmpty()) { "Das ONNX-Modell hat keinen Ausgang." }
            val candidateInputName = opened.inputNames.first()
            val info = opened.inputInfo[candidateInputName]?.info as? TensorInfo
                ?: throw IllegalArgumentException("Der Modelleingang ist kein Tensor.")
            require(info.type.toString().contains("FLOAT", ignoreCase = true)) {
                "Unterstützt werden aktuell FLOAT-Audio-Modelle."
            }
            val shape = info.shape
            require(shape.size == 2 && (shape[0] == 1L || shape[0] < 0L)) {
                "Erwartete Eingabeform [1, Samples], erhalten: ${shape.contentToString()}"
            }
            require(shape[1] <= 0L || shape[1] == LIVE_FRAME_SIZE.toLong()) {
                "Dieses Live-Profil verarbeitet $LIVE_FRAME_SIZE Samples pro Block. Das Modell erwartet ${shape[1]} Samples und ist daher nicht kompatibel."
            }
            inputName = candidateInputName
            inputFrameCount = shape[1].takeIf { it > 0L }?.toInt()
            session = opened
        } catch (t: Throwable) {
            opened.close()
            throw t
        }
    }

    fun process(samples: FloatArray): FloatArray {
        val desiredSize = inputFrameCount ?: samples.size
        val input = FloatArray(desiredSize)
        if (samples.isNotEmpty()) {
            val copy = minOf(samples.size, desiredSize)
            System.arraycopy(samples, 0, input, 0, copy)
        }
        val inputBuffer = ByteBuffer.allocateDirect(input.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        inputBuffer.put(input)
        inputBuffer.rewind()
        OnnxTensor.createTensor(environment, inputBuffer, longArrayOf(1L, input.size.toLong())).use { tensor ->
            session.run(mapOf(inputName to tensor)).use { result ->
                val out = result[0] as? OnnxTensor
                    ?: throw IllegalStateException("Der Modellausgang ist kein Tensor.")
                val buffer = out.floatBuffer?.duplicate()
                    ?: throw IllegalStateException("Der Modellausgang enthält keine FLOAT-Daten.")
                val available = buffer.remaining()
                require(available > 0) { "Das Modell hat keine Audio-Samples ausgegeben." }
                val raw = FloatArray(available)
                buffer.get(raw)
                val fitted = FloatArray(samples.size)
                val copy = minOf(raw.size, fitted.size)
                System.arraycopy(raw, 0, fitted, 0, copy)
                if (copy > 0 && copy < fitted.size) {
                    val end = raw[copy - 1]
                    for (i in copy until fitted.size) {
                        fitted[i] = end * (1f - (i - copy + 1f) / (fitted.size - copy + 1f))
                    }
                }
                return fitted
            }
        }
    }

    override fun close() { session.close() }

    private companion object {
        const val LIVE_FRAME_SIZE = 1024
    }
}
