package com.voiceshift.mobile.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.tanh

internal class VoiceEffects {
    private var robotPhase = 0.0
    private var alienPhase = 0.0
    private var radioPreviousInput = 0f
    private var radioHighPass = 0f
    private var radioLowPass = 0f
    private var alienMemory = 0f
    private var lastEffect = ""

    fun process(input: FloatArray, effect: String): FloatArray {
        val key = effect.uppercase()
        if (key != lastEffect) {
            robotPhase = 0.0
            alienPhase = 0.0
            radioPreviousInput = 0f
            radioHighPass = 0f
            radioLowPass = 0f
            alienMemory = 0f
            lastEffect = key
        }
        return when (key) {
            "ROBOT" -> robot(input)
            "RADIO" -> radio(input)
            "ALIEN" -> alien(input)
            else -> FloatArray(input.size) { i -> (input[i] * 0.95f).coerceIn(-1f, 1f) }
        }
    }

    private fun robot(input: FloatArray): FloatArray {
        val output = FloatArray(input.size)
        val step = 2.0 * PI * 42.0 / 48_000.0
        for (i in input.indices) {
            val carrier = sin(robotPhase).toFloat()
            output[i] = tanh(input[i] * (0.25f + 0.75f * abs(carrier)) * 1.8f)
            robotPhase += step
            if (robotPhase >= 2.0 * PI) robotPhase -= 2.0 * PI
        }
        return output
    }

    private fun radio(input: FloatArray): FloatArray {
        val output = FloatArray(input.size)
        for (i in input.indices) {
            val x = input[i]
            radioHighPass = 0.91f * (radioHighPass + x - radioPreviousInput)
            radioPreviousInput = x
            radioLowPass += 0.24f * (radioHighPass - radioLowPass)
            val quantized = (radioLowPass * 42f).toInt() / 42f
            output[i] = tanh(quantized * 1.5f)
        }
        return output
    }

    private fun alien(input: FloatArray): FloatArray {
        val output = FloatArray(input.size)
        val step = 2.0 * PI * 17.0 / 48_000.0
        for (i in input.indices) {
            val mod = 0.35f + 0.65f * sin(alienPhase).toFloat()
            val x = input[i] * mod
            alienMemory = 0.7f * alienMemory + 0.3f * x
            output[i] = tanh((x + alienMemory * 0.5f) * 1.8f)
            alienPhase += step
            if (alienPhase >= 2.0 * PI) alienPhase -= 2.0 * PI
        }
        return output
    }
}
