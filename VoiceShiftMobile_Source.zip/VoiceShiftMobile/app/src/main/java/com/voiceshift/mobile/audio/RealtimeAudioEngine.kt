package com.voiceshift.mobile.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioManager
import android.os.Process
import com.voiceshift.mobile.model.OnnxAudioModel
import java.util.concurrent.atomic.AtomicBoolean

class RealtimeAudioEngine(
    private val onStatus: (String) -> Unit,
    private var monitoring: Boolean,
    private var effect: String,
    private var modelPath: String?
) {
    companion object {
        private const val SAMPLE_RATE = 48_000
        private const val FRAMES = 1024
    }

    private val running = AtomicBoolean(false)
    @Volatile private var activeEffect = effect
    @Volatile private var monitorOutput = monitoring
    @Volatile private var pendingModelPath: String? = modelPath
    @Volatile private var modelReloadRequested = true
    private var worker: Thread? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var loadedModel: OnnxAudioModel? = null
    private val effects = VoiceEffects()
    private var failedModelPath: String? = null

    fun setMonitoring(enabled: Boolean) { monitorOutput = enabled }
    fun setEffect(name: String) { activeEffect = name }
    fun setModel(path: String?) { pendingModelPath = path; modelReloadRequested = true }

    fun start() {
        if (!running.compareAndSet(false, true)) return
        try {
            val minRecord = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val minTrack = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            require(minRecord > 0 && minTrack > 0) { "Dieses Gerät unterstützt die benötigte 48-kHz-Audiokonfiguration nicht." }
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minRecord, FRAMES * 4)
            )
            require(recorder?.state == AudioRecord.STATE_INITIALIZED) { "Das Mikrofon konnte nicht gestartet werden." }
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            player = AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(AudioFormat.Builder().setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(maxOf(minTrack, FRAMES * 4 * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            recorder?.startRecording()
            player?.play()
            worker = Thread({ audioLoop() }, "VoiceShift-Audio").apply {
                priority = Thread.MAX_PRIORITY
                start()
            }
            onStatus("Mikrofon aktiv · lokale Verarbeitung gestartet")
        } catch (t: Throwable) {
            stop()
            onStatus("Startfehler: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        val input = ShortArray(FRAMES)
        var modelFailureReported = false
        while (running.get()) {
            try {
                if (modelReloadRequested) reloadModel()
                val read = recorder?.read(input, 0, input.size, AudioRecord.READ_BLOCKING) ?: -1
                if (read <= 0) continue
                val floats = FloatArray(read) { i -> input[i] / 32768f }
                val processed = try {
                    loadedModel?.process(floats) ?: effects.process(floats, activeEffect)
                } catch (t: Throwable) {
                    if (!modelFailureReported) {
                        onStatus("Modellfehler: ${t.message ?: "unbekannter Fehler"}. DSP-Effekt aktiv.")
                        modelFailureReported = true
                    }
                    loadedModel?.close()
                    loadedModel = null
                    effects.process(floats, activeEffect)
                }
                val output = ShortArray(processed.size) { i ->
                    val value = processed[i].coerceIn(-1f, 1f)
                    (value * 32767f).toInt().toShort()
                }
                // Monitoring is for local listening only; Android does not expose this track as
                // a virtual microphone to Roblox or other apps.
                if (monitorOutput) player?.write(output, 0, output.size, AudioTrack.WRITE_BLOCKING)
            } catch (t: Throwable) {
                if (running.get()) onStatus("Audio-Fehler: ${t.message ?: t.javaClass.simpleName}")
                break
            }
        }
    }

    @Synchronized private fun reloadModel() {
        modelReloadRequested = false
        loadedModel?.close(); loadedModel = null
        val target = pendingModelPath
        if (target.isNullOrBlank()) {
            failedModelPath = null
            onStatus("DSP-Effekt aktiv · kein KI-Modell ausgewählt")
            return
        }
        if (target == failedModelPath) return
        try {
            loadedModel = OnnxAudioModel(target)
            failedModelPath = null
            onStatus("ONNX-Audiomodell geladen · experimenteller Einzel-Eingang")
        } catch (t: Throwable) {
            failedModelPath = target
            onStatus("Modell nicht kompatibel: ${t.message ?: "Ladefehler"}")
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        try { recorder?.stop() } catch (_: Throwable) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Throwable) {}
        try { worker?.join(500) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        worker = null
        try { recorder?.release() } catch (_: Throwable) {}
        try { player?.release() } catch (_: Throwable) {}
        recorder = null; player = null
        try { loadedModel?.close() } catch (_: Throwable) {}
        loadedModel = null
        onStatus("Gestoppt")
    }

    fun isRunning() = running.get()
}
